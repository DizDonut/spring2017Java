import java.util.Scanner;
import java.io.*;

public class DriverDemo
{
   public static void main(String[] a) throws IOException
   {
      Scanner k = new Scanner(System.in);
      File f = new File("VehicleInformation.txt");
      Scanner inputFile = new Scanner(f);
      
      //declare and initialize variables
      int vehicleCount = 0;
      
      Vehicle v = new Vehicle();
      
      String type, make, year, options;
      double basePrice, optionsFee, finalPrice;
      double totalPrice = 0, avgPrice = 0;
      
      while(inputFile.hasNext())
      {
         v.setType(inputFile.nextLine());
         v.setMake(inputFile.nextLine());
         v.setYear(inputFile.nextLine());
         v.setBasePrice(inputFile.nextDouble());
         inputFile.nextLine();
         v.setOptions(inputFile.nextLine());
         
         if(inputFile.hasNext())
         {
            inputFile.nextLine();
         }
         
         vehicleCount++;
         v.setFinalPrice(v.calcFinalPrice(v.getBasePrice(), v.getOptions()));
         
         v.display(v.getType(), v.getMake(), v.getYear(), v.getBasePrice(), v.getOptions(), v.getFinalPrice());
         
         totalPrice += v.getFinalPrice();
         
      }//end while loop
      
      avgPrice = totalPrice / vehicleCount;
      
      System.out.println("---------------------------------------------");
      System.out.printf("Total price of all vehicles:\t\t$%,.2f\n", totalPrice);
      System.out.printf("Average price of all vehicles:\t$%,.2f\n", avgPrice);  
    }//end main method
   
   }